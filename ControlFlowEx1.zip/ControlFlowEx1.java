package com.nttdata.JavaBasics;

public class ControlFlowEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int aNumber=3;
		if(aNumber>=0)
			if(aNumber==0)
				System.out.println("first string");
			else
				System.out.println("Second string");
		System.out.println("Third string");
	}
}
	
